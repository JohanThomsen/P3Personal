﻿namespace FklubStregSystemEksamen.Data
{
    public interface IDatabase
    {
    }
}