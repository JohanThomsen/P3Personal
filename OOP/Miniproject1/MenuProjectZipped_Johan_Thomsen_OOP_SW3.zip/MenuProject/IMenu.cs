﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MenuProject
{
    public interface IMenu
    {
        public void Select();
    }
}
